package com.example.applicationdemo;

import androidx.lifecycle.ViewModel;

public class CreateViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}