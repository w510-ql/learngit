package com.example.applicationdemo;

import androidx.lifecycle.ViewModel;

public class PersonalViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}